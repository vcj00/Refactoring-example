/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.calculator_inside;

import java.util.Scanner;

/**
 *
 * @author alu_tarde
 */
public class Calculator_Inside {

    public static void main(String[] args) {

        int opc;
        Scanner sc = new Scanner(System.in);
        Calculadora c1 = new Calculadora();
        
        do {
            /*
            System.out.println(" Bienvenido a la calculadora elige una opción");
            System.out.println("1. Sumar");
            System.out.println("2.Restar");
            System.out.println("3.Multiplicar");
            System.out.println("4.Dividir");
            System.out.println("5.Sumatorio");
            System.out.println("6.Factor");

            opc = sc.nextInt();

            switch (opc) {

                case 1:
                    c1.sumar();
                    break;

                case 2:
                    c1.restar();
                    break;

                case 3:
                    c1.multiplicar();
                    break;

                case 4:
                    c1.dividir();
                    break;

            }//switch end

        } while (opc != 0);
*/
    }//main end
}//class end
