/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculator_inside;

/**
 *
 * @author alu_tarde
 */
public class Calculadora {

    public int sumar() {

        return 1;
    }

    public int restar() {
        return 2;
    }

    public int multiplicar() {
        return 2;
    }

    public int dividir() {

    }
}
